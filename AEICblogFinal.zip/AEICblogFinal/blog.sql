-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 15 nov. 2018 à 00:25
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `blog`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) DEFAULT NULL,
  `contenu` longtext,
  `date` datetime DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_articles` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id`, `titre`, `contenu`, `date`, `category_id`) VALUES
(11, 'Bienvenue! ', 'Bienvenue sur le blog de l\'AEIC - HelpCenter!\r\nCe blog permet de stocker les cours de 1Ã¨re et 2Ã¨me annÃ©e de DUT Informatique de l\'IUT de Calais. Ils sont donc partagÃ©s avec vous tous, ce qui pourra vous permettre de vous rattraper en cas d\'absence, ou bien si vous ne suivez pas bien en cours :p.', NULL, 1),
(7, 'Economie - Chapitre 1: Les entreprises', 'Incenderat autem audaces usque ad insaniam homines ad haec, quae nefariis egere conatibus, Luscus quidam curator urbis subito visus: eosque ut heiulans baiolorum praecentor ad expediendum quod orsi sunt incitans vocibus crebris. qui haut longe postea ideo vivus exustus est.', NULL, 2),
(12, 'PHP - Projet Site Web', 'Vous devez rÃ©flÃ©chir Ã  un projet pour lequel vous devrez crÃ©er un site web en relation avec tout ce que vous avez appris cette annÃ©e dans le module.\r\n\r\nVous avez un mois pour faire ce projet, une note vous sera attribuÃ©e.', NULL, 1),
(5, 'Les Bases de DonnÃ©es - Chapitre 9: Normalisation', 'Dans une base de donnÃ©es relationnelle, une forme normale dÃ©signe un type de relation particulier entre les entitÃ©s.\r\n\r\nLe but essentiel de la normalisation est d\'Ã©viter les anomalies transactionnelles pouvant dÃ©couler d\'une mauvaise modÃ©lisation des donnÃ©es et ainsi Ã©viter un certain nombre de problÃ¨mes potentiels tels que les anomalies de lecture, les anomalies d\'Ã©criture, la redondance des donnÃ©es et la contre-performance.\r\n\r\nLa normalisation des modÃ¨les de donnÃ©es permet de vÃ©rifier la robustesse de leur conception pour amÃ©liorer la modÃ©lisation (et donc obtenir une meilleure reprÃ©sentation) et faciliter la mÃ©morisation des donnÃ©es en Ã©vitant la redondance et les problÃ¨mes sous-jacents de mise Ã  jour ou de cohÃ©rence. La normalisation sâ€™applique Ã  toutes les entitÃ©s et aux relations porteuses de propriÃ©tÃ©s.\r\n\r\nLes formes normales s\'emboitent les unes dans les autres, tant et si bien que le respect d\'une forme normale de niveau supÃ©rieur implique le respect des formes normales des niveaux infÃ©rieurs. Dans le modÃ¨le relationnel de type OLTP, il existe huit formes normales, les trois premiÃ¨res Ã©tant les plus connues et utilisÃ©es :\r\n\r\n    la premiÃ¨re forme normale notÃ©e 1FN (1NF en anglais) ;\r\n    la deuxiÃ¨me forme normale notÃ©e 2FN (2NF en anglais) ;\r\n    la troisiÃ¨me forme normale notÃ©e 3FN (3NF en anglais) ;\r\n    la forme normale de Boyce Codd notÃ©e FNBC (BCNF en anglais) ;\r\n    la quatriÃ¨me forme normale notÃ©e 4FN (4NF en anglais) ;\r\n    la cinquiÃ¨me forme normale notÃ©e 5FN (5NF en anglais) ;\r\n    la forme normale domaine clef notÃ©e FNDC (DKNF en anglais) ;\r\n    la sixiÃ¨me forme normale notÃ©e 6FN (6NF en anglais) rarement prÃ©sentÃ©e.', NULL, 2);

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `titre`) VALUES
(1, '1ere_annee'),
(2, '2eme_annee');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'demo', '89e495e7941cf9e40e6980d14a16bf023ccd4c91');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
