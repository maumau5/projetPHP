<?php

CarFactory::getCar('Citadine');