<?php 

class Car4x4 extends Car{

    
}