<?php

return array(
    "db_user" => "root",
    "db_pass" => "bruh",
    "db_host" => "localhost",
    "db_name" => "blog"
);